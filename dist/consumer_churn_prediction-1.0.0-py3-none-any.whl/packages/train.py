import numpy as np
import pandas as pd
from preprocessing import full_pipeline,preprocessing_pipeline
from sklearn.linear_model import LogisticRegression
import cloudpickle

#Importing raw data
df=pd.read_csv("/Users/swikritsubedi/Desktop/Python/Consumer Churn Prediction/data/Raw/raw.csv")

#selecting features for training
churn_data=df["Churn"]
data=df.drop(["customerID","Churn"],axis=1)

#selecting training data
x_train=data.iloc[:3000,:]
y_train=churn_data.iloc[:3000]


model=LogisticRegression()

final_pipeline=full_pipeline(model)
final_pipeline.fit(x_train,y_train)

#saving the model
with open("/Users/swikritsubedi/Desktop/Python/Consumer Churn Prediction/models/full_pipeline.pkl","wb") as f:
    cloudpickle.dump(full_pipeline,f)